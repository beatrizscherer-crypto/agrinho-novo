/* =========================
   ANIMAÇÃO AO ROLAR A PÁGINA
========================= */
const cards = document.querySelectorAll(".card");

const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            entry.target.classList.add("show");
        }
    });
}, {
    threshold: 0.2
});

cards.forEach(card => observer.observe(card));


/* =========================
   GRÁFICO (IBGE SIMULADO)
   usando Chart.js
========================= */
const ctx = document.getElementById("graficoAgricultura");

if (ctx) {
    new Chart(ctx, {
        type: "bar",
        data: {
            labels: ["Soja", "Milho", "Arroz", "Feijão", "Outros"],
            datasets: [{
                label: "Produção (milhões de toneladas)",
                data: [160, 110, 25, 15, 20],
                backgroundColor: [
                    "#2e7d32",
                    "#43a047",
                    "#66bb6a",
                    "#81c784",
                    "#a5d6a7"
                ],
                borderRadius: 8
            }]
        },
        options: {
            responsive: true,
            animation: {
                duration: 2000,
                easing: "easeOutQuart"
            },
            plugins: {
                legend: {
                    display: true
                }
            }
        }
    });
}


/* =========================
   CONTADOR ANIMADO (IBGE)
========================= */
function animateValue(id, start, end, duration) {
    const obj = document.getElementById(id);
    if (!obj) return;

    let startTimestamp = null;

    const step = (timestamp) => {
        if (!startTimestamp) startTimestamp = timestamp;

        const progress = Math.min((timestamp - startTimestamp) / duration, 1);

        obj.innerText = Math.floor(progress * (end - start) + start).toLocaleString();

        if (progress < 1) {
            window.requestAnimationFrame(step);
        }
    };

    window.requestAnimationFrame(step);
}

// Exemplo de uso (se você criar esses IDs no HTML)
animateValue("totalProducao", 0, 330, 2000);
animateValue("crescimento", 0, 32, 2000);


/* =========================
   EFEITO HOVER DINÂMICO
========================= */
cards.forEach(card => {
    card.addEventListener("mousemove", () => {
        card.style.transform = "scale(1.02)";
        card.style.transition = "0.3s";
    });

    card.addEventListener("mouseleave", () => {
        card.style.transform = "scale(1)";
    });
});


/* =========================
   LOG DE CARREGAMENTO
========================= */
window.addEventListener("load", () => {
    console.log("🌱 Site Agrinho 2026 carregado com sucesso!");
});